import "./CuratedExperience.css";

const CuratedExperience = () => {
  const images = [
    { src: "https://picsum.photos/300/200?random=1", name: "Picture One" },
    { src: "https://picsum.photos/300/200?random=2", name: "Picture Two" },
    { src: "https://picsum.photos/300/200?random=3", name: "Picture Three" },
    { src: "https://picsum.photos/300/200?random=4", name: "Picture Four" },
    { src: "https://picsum.photos/300/200?random=5", name: "Picture Five" },
    { src: "https://picsum.photos/300/200?random=6", name: "Picture Six" },
   

  ];
  return (
    <div className="main-container mt-10">
      <div className="header">
        <h1>Welcome to the Gallery</h1>
        <p>Explore the collection by hovering over the cards!</p>
      </div>

      <div className="grid grid-cols-[repeat(auto-fit,minmax(300px,1fr))] gap-6 w-full max-w-[1200px] ">
        {images.map((image, index) => (
          <div key={index} className="card ">
            <div className="card-front rounded-xl">
              <img src={image.src} alt={image.name} />
            </div>
            <div className="card-back rounded-xl">
              <h2>{image.name}</h2>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CuratedExperience;